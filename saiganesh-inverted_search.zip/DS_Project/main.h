#ifndef MAIN_H
#define MAIN_H

#define WORD_SIZE 50
#define FILE_SIZE 50

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SUCCESS 0
#define FAILURE -1

//structure for table
typedef struct table_n
{
	int index;
	struct main*link;
}table_n_t;

//structure for main node
typedef struct main
{
	int file_count;
	char word[WORD_SIZE];
	struct sub*sublink;
	struct main*mainlink;
}main_n_t;

//structure for sub node
typedef struct sub
{
	int word_count;
	char file_name[FILE_SIZE];
	struct sub*sublink;
}sub_n_t;

//structure for file
typedef struct file
{
	char file_name[FILE_SIZE];
	struct file*link;
}file_t;

//function prototypes
int read_and_validate(int argc,char*argv[],file_t **file);
int insert_at_last(file_t **file, char* string);
void print_list(file_t *file);
int create_db(table_n_t *table_n,file_t *file);
int print_db(table_n_t *table_n);
int search_db(table_n_t *table_n,char *str);
int save_db(table_n_t *table_n);
int update_db(table_n_t *table_n,char *file);

#endif

#include "main.h"

//to search the data in the database
int search_db(table_n_t *table_n,char *str)
{
	//declaring local variables
	int count=0;
	int index=tolower(str[0])-97;
	//intiliase temp
	main_n_t *maintemp=table_n[index].link;
	//to traverse temp and compare the data
	while(maintemp)
	{
		if(strcmp(maintemp->word,str)==0)
		{
			count=1;
			//to print the data present which matches the given data
			printf("%s is present in %d files\n",str,maintemp->file_count);
			sub_n_t *subtemp = maintemp->sublink;
			//to search the data and print corresponding filename and wordcount
			while(subtemp)
			{
				printf("in %s for %d times\n",subtemp->file_name,subtemp->word_count);
				subtemp=subtemp->sublink;
			}
		}
		maintemp=maintemp->mainlink;
	}
	//if data is not found
	if(count==0)
	{
		printf("Data not found\n");
	}
}

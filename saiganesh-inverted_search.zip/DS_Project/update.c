#include "main.h"

//function to update the database
int update_db(table_n_t *table_n,char *file1)
{
	//initiliase the file pointer and to open the input file which consists the saved database
	FILE*ptr=fopen(file1,"r");
	if(ptr==NULL)
	{
		return FAILURE;
	}
	//declaring local variables
	char del[10]="#<>";
	char str[50];
	//to read the data from the file to string
	while(fscanf(ptr,"%s",str)>0)
	{
		//fgetc(ptr);
		//intiliase the index with atoi function and to use string token function using delimeters
		int ind = atoi(strtok(str,del));
		fscanf(ptr,"%s",str);
		//fgetc(ptr);
		//to read the contents of main node and update it
		main_n_t *maintemp=malloc(sizeof(main_n_t));
		strcpy(maintemp->word,strtok(str,del));
		maintemp->file_count=atoi(strtok(NULL,del));
		maintemp->sublink=NULL;
		maintemp->mainlink=NULL;
		//to read the contents of subnode and update
		for(int i=0;i<maintemp->file_count;i++)
		{
			sub_n_t*subtemp=malloc(sizeof(sub_n_t));
			strcpy(subtemp->file_name,strtok(NULL,del));
			subtemp->word_count=atoi(strtok(NULL,del));
			subtemp->sublink=NULL;
			//to link the sub node to main node sublink part
			if(maintemp->sublink==NULL)
			{
				maintemp->sublink=subtemp;
			}
			//to to update the sub node's linkpart
			else
			{
				sub_n_t*subtemp1=maintemp->sublink;
				while(subtemp1->sublink !=NULL)
				{
					subtemp1=subtemp1->sublink;
				}
				subtemp1->sublink=subtemp;
			}
		}
		//to link main node to hashtable link part
		if(table_n[ind].link==NULL)
		{
			table_n[ind].link=maintemp;
		}
		//to update main node's linkpart
		else
		{
			main_n_t*maintemp1=table_n[ind].link;
			while(maintemp1->mainlink!=NULL)
			{
				maintemp1=maintemp1->mainlink;
			}
			maintemp1->mainlink=maintemp;
		}
	}
	//close the file pointer
	fclose(ptr);
	return SUCCESS;
}








#include "main.h"

//fuction to print the database
int print_db(table_n_t *table_n)
{
	//to run a loop untill 26 alphabets and other for special character
	for(int i=0;i<27;i++)
	{
		//declare temp
		main_n_t *maintemp=table_n[i].link;
		//to traverse  temp and print the data in the main node
		while(maintemp)
		{
			printf("<%d>",i);
			printf("<%s>",maintemp->word);
			printf("<%d>",maintemp->file_count);
			sub_n_t *subtemp=maintemp->sublink;
			//to traverse subtemp and print the data in the sub node
			while(subtemp)
			{
				printf("<%s>",subtemp->file_name);
				printf("<%d>",subtemp->word_count);
				subtemp=subtemp->sublink;
			}
			printf("\n");
			maintemp=maintemp->mainlink;
		}
	}
	return SUCCESS;
}


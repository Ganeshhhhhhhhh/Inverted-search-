#include "main.h"

//function to save the database
int save_db(table_n_t *table_n)
{
	//declaring local variables
	char str[30];
	//to read the filename to save the contents of the database
	printf("Enter the file name:");
	scanf("%s",str);
	//to validate txt file
	if(strstr(str,".txt")==NULL)
	{
		printf("pass .txt file\n");
		return FAILURE;
	}
	//initiliase file pointer
	FILE *ptr=NULL;
	ptr=fopen(str,"w");
	//to run a loop for table index
	for(int i=0;i<27;i++)
	{
		//initiliase a temp pointer
		main_n_t*maintemp=table_n[i].link;
		//to traverse temp
		while(maintemp)
		{
			//to save the contents of main node 
			fprintf(ptr,"<%d>\n",i);
			fprintf(ptr,"<%s>",maintemp->word);
			fprintf(ptr,"<%d>",maintemp->file_count);
			sub_n_t*subtemp=maintemp->sublink;
			//to traverse in subnode
			while(subtemp)
			{
				//to save the contents of sub node
				fprintf(ptr,"<%s>",subtemp->file_name);
				fprintf(ptr,"<%d>",subtemp->word_count);
				subtemp=subtemp->sublink;
			}
			//to print the contents in the file
			fprintf(ptr,"#\n");
			maintemp=maintemp->mainlink;
		}
	}
	fclose(ptr);
	return SUCCESS;
}




#include "main.h"

int create_db(table_n_t *table_n,file_t *file)
{
	//initliase a file pointer
	FILE *fptr=NULL;
	//declaring local variables
	char string[30];
	int ind;
	while(file!=NULL)
	{
		fptr=fopen(file->file_name,"r");
		while(fscanf(fptr,"%s",string)>0)
		{
			//to get index
			ind = tolower(string[0])-97;
			if(!(ind >= 0 && ind <=25))
			{
				ind=26;
			}
			//to take a temp pointer which points to table link part
			main_n_t *maintemp = table_n[ind].link;
			int count=0;
			//if already there is main node
			if(maintemp!=NULL)
			{
				//to traverse maintemp 
				while(maintemp -> mainlink != NULL)
				{
					//to compare the word with the string
					if(strcmp(maintemp -> word,string) == 0)
					{
						count=1;
						break;
					}
					maintemp=maintemp->mainlink;
				}
				if(strcmp(maintemp -> word,string) == 0)
				{
					count=1;
				}
			}
			//to create main node
			if(count == 0)
			{
				main_n_t *newmain=malloc(sizeof(main_n_t));
	 			strcpy(newmain -> word,string);
				newmain->file_count=1;
				newmain->mainlink=NULL;
				newmain->sublink=NULL;
				if(maintemp == NULL)
				{
					table_n[ind].link = newmain;
				}
				else
				{
					maintemp -> mainlink = newmain;
				}
				//to create a sub node
				sub_n_t *newsub = malloc(sizeof(sub_n_t));
				strcpy(newsub->file_name,file->file_name);
				newsub->word_count=1;
				newsub->sublink=NULL;
				newmain -> sublink=newsub;
			}
			//if there is already word/node is present
			else if(count == 1)
			{
				int count1=0;
				sub_n_t *subtemp = maintemp->sublink;
				while(subtemp->sublink != NULL)
				{
					if(strcmp(subtemp->file_name,file->file_name)==0)
					{
						(subtemp -> word_count)++;
						count1 = 1;
					   	break;
					}
					subtemp=subtemp->sublink;
				}
				if(strcmp(subtemp->file_name,file->file_name)==0)
				{
					(subtemp->word_count)++;	
					count1 = 1;
				}
				//to create further new sub node
				if(count1 == 0)
				{
					sub_n_t *subtemp1 =  malloc(sizeof(sub_n_t));
					strcpy(subtemp1->file_name,file->file_name);
					subtemp1->sublink=NULL;
					subtemp1->word_count=1;
					subtemp -> sublink = subtemp1;
					(maintemp -> file_count)++;
				}

			}

		}
		//to close file pointer
		fclose(fptr);
		//to traverse file
		file=file->link;
	}
	return SUCCESS;
}








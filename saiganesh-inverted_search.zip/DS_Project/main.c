#include "main.h"

int main(int argc,char*argv[])
{
	file_t *file_n=NULL;
	char str[20];
	table_n_t table[27];
	//validation of input arguments
	if(argc<2)
	{
		printf("ERROR: INVALID!! PLEASE PASS VALID ARGUMENTS \n");
		printf("Usage: ./a.out file1.txt file2.txt file3.txt \n");
	}
	else
	{
		int option;
		//fill the parts of the table
		for(int i=0;i<27;i++)
		{
			table[i].index=i;
			table[i].link=NULL;
		}
		//function to read and validate
		if(read_and_validate(argc,argv,&file_n)==SUCCESS)
		{
			printf("read and validate success\n");
		}
		else
		{
			printf("read and validate not success\n");
			return 0;
		}
		print_list(file_n);
		while(1)
		{
			printf("\nenter operation\n1. Create database\n2. Display database\n3. Search database\n4. Save database\n5. Update database\n6. Exit\nEnter your choice : ");
			scanf("%d",&option);
			switch(option)
			{
				//create database
				case 1:
					if(create_db(table,file_n)==SUCCESS)
					{
						printf("Created database successfully\n");
					}
					else
					{
						printf("Database not created successfully\n");
					}
					break;
				//display database
				case 2:
					print_db(table);
					break;
				//search data in database
				case 3:
					printf("Enter data to search\n");
					scanf("%s",str);
					search_db(table,str);
					break;
				//to save the database
				case 4:
					if(save_db(table)==SUCCESS)
					{
						printf("Database saved successfully\n");
					}
					else
					{
						printf("Database saving failed\n");
					}
					break;
				//to update database
				case 5:
					printf("Enter the file name:\n");
					scanf("%s",str);
					if(update_db(table,str)==SUCCESS)
					{
						printf("Database updated successfully\n");
					}
					else
					{
						printf("Database not updated successfully\n");
					}
					break;
				default:
					printf("Enter valid key\n");
			}
		}			
	}
}

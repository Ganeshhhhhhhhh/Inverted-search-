#include "main.h"

void print_list(file_t *file)
{
	//checking whether the list is empty
	if (file == NULL)
	  {
	  printf("INFO : List is empty\n");
	  }
	//printing the list elements
	printf("The files are: \n");
	while (file)
	{
		printf("%s  ", file -> file_name);
		file = file -> link;
	}
}

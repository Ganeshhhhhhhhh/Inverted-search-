#include "main.h"

int read_and_validate(int argc,char*argv[], file_t **file_n)
{
	//to run lopp untill count of arguments passed
	for(int i=1;i<argc;i++)
	{
		//to pass only txt file
		if(strstr(argv[i],".txt")!=NULL)
		{
			//to read the input file passed
			FILE *ptr=fopen(argv[i],"r");
			//to check whether the file is present
			if(ptr!=NULL)
			{
				fseek(ptr,0,SEEK_END);
				//to check whether the file is empty
				if(ftell(ptr) != 0)
				{
					file_t *temp=*file_n;
					int count=0;
					//to check duplicates
					while(temp!=NULL)
					{
						if(strcmp(temp->file_name,argv[i]) == 0)
						{
							printf("%s is already present\n",argv[i]);
							count=1;
							break;
						}
						temp=temp->link;
					}
					//insert the file in a list
					if(count == 0)
					{
						insert_at_last(file_n,argv[i]);
					}
				}
				else
				{
					printf("%s is a empty file",argv[i]);
				}
				fclose(ptr);
			}
			else
			{
				printf("File %s  is not present\n",argv[i]);
			}
		}
		else
		{
			printf("Please pass valid file extension\n");
			printf("Usage: ./a.out file1.txt file2.txt\n");
		}
	}
	return SUCCESS;
}

int insert_at_last(file_t **file_n, char* string)
{
	//creating new node
	file_t *new=malloc(sizeof(file_t));
	//to check whether new node is created
	if(new == NULL)
	{
		return FAILURE;
	}
	//filling the parts of the node
	strcpy(new->file_name,string);
	new -> link = NULL;

	//if head or list is empty
	if(*file_n == NULL)
	{
		*file_n=new;
		return SUCCESS;
	}
	//creating new structure pointer
	file_t *temp = *file_n;
	//to traverse
	while(temp -> link != NULL)
	{
		temp=temp->link;
	}
	//to store the link part of the temp to new
	temp->link=new;
	return SUCCESS;
}








